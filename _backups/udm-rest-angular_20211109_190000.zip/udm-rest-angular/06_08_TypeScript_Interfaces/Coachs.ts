/**
 *=06. TypeScript Crash Course - Inheritance and Interfaces
 *     27. Interfaces - Overview
 *     28. Interfaces - Write Some Code
 */


/**
 *=Interface Coach
 */
export interface Coach {
    //--Interface Method Contract (no body, no implementation at this level)
    getDailyWorkout(): string;
}
